'use strict';

const express = require('express');

const PORT = 80;
const HOST = '0.0.0.0';

const app = express();
let ts = Date.now();
let date_ob = new Date(ts);
let date = date_ob.getDate();
let month = date_ob.getMonth() + 1;
let year = date_ob.getFullYear();
app.get('/', (req, res) => {
  res.send(year + "-" + month + "-" + date);
});

app.listen(PORT, HOST);
console.log(`Running on http://${HOST}:${PORT}`);